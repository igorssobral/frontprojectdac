import React from "react";
import './AppCont.css'

export default class AppCont extends React.Component{


    render(){
        
        return(

            
            <div class="App-cont">
                {this.props.children}
            </div>


        );

    
    }
}