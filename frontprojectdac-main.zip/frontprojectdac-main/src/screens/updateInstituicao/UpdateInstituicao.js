import React from "react";
import axios from "axios";
import { withRouter } from "react-router-dom";
import FormGroup from "../../components/FormGroup";
import Card from "../../components/Card";


class UpdateInstituicao extends React.Component {


    state = {
        id: 0,
        name : 'fff',
        email: 'fgfg',
        telefone: '3434', 
        
    }

  
   
   

    update = () => {
        axios.put(`http://localhost:8080/Instituicao/${this.state.id}`, 
            {
                name: this.state.name,
                email: this.state.email,
                telfone: this.state.telefone
               
            }
        )

        
    }

    cancel = () => {
        this.props.history.push('/');
    }




    render() {
        return (
            <div className='container'>
                <Card title="Atualização da Instituicao">
                    <div className="row">
                        <div className="col-lg-12">
                            <div className="bs-component">
                    <FormGroup label="Nome" htmlFor="inputNome">
                        
                        <input type="text" className="form-control"
                            placeholder="Digite o nome" id="inputNome"
                            value={this.state.nome}
                            onChange={(e) => this.setState({ nome: e.target.value })} />
                    </FormGroup>
                    
                    <FormGroup label="Email" htmlFor="inputEmail">
                        <input type="email" className="form-control" placeholder="Digite um email" id="inputEmail"
                            value={this.state.email} onChange={(e) => this.setState({ email: e.target.value })} />
                    </FormGroup>
                    <FormGroup label="Telefone" htmlFor="inputTelefone">
                        
                        <input type="tel" className="form-control" placeholder="Digite um telefone" id="inputTelefone"
                            value={this.state.telefone} onChange={(e) => this.setState({ telefone: e.target.value })} />
                    </FormGroup>
                    <br />
                    <button  type="button" className="btn btn-success">Buscar</button>
                    <br />
                    <br />
                    <button onClick={this.update} type="button" className="btn btn-success">
                        <i className="pi pi-save"></i> Atualizar
                    </button>
                    <button onClick={this.cancel} type="button" className="btn btn-danger">
                        <i className="pi pi-times"></i> Cancelar

                    </button>
                    <br />
                    <div className="row" >
                        <div className="col-md-12">
                            <div className="bs-component" >



                            </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    </div>

            </Card>
                
            </div>
        )
    }
}

export default withRouter(UpdateInstituicao);