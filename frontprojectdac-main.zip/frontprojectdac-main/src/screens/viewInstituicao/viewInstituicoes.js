import React from "react";

import { withRouter } from "react-router-dom";
import axios from 'axios';

import InstituicaoTables from "../../components/InstituicaoTables";

import './ViewInstituicoes.css'
import FormGroup from "../../components/FormGroup";
import Card from "../../components/Card";

 class ViewInstituicao extends React.Component {


    state = {
        name: 'igor',
        email: 'igor@gmail.com',
        telefone: '8888',
        id: '1',
        instituicoes: [{
            name: 'igor',
        email: 'igor@gmail.com',
        telefone: '8888',
        id: '1'
        }]
    }

    find = () => {
        var params = '?';

        if (this.state.id !== '') {
            if (params !== '?') {
                params = `${params}$`;
            }

            params = `${params}name=${this.state.id}`
        }
        if (this.state.nome !== '') {
            if (params !== '?') {
                params = `${params}$`;
            }

            params = `${params}name=${this.state.nome}`
        }
        if (this.state.email !== '') {
            if (params !== '?') {
                params = `${params}$`;
            }

            params = `${params}name=${this.state.email}`
        }
        if (this.state.telefone !== '') {
            if (params !== '?') {
                params = `${params}$`;
            }

            params = `${params}name=${this.state.telefone}`
        }
        axios.get(`http://localhost:8080/Instituicao${params}`)
            .then(response => {
                const instituicoes = response.data;
                this.setState({ instituicoes });
                console.log(instituicoes)
            }
            ).catch(error => {
                console.log(error.response);
            }
            );
    }
    delete = (instituicaoId) => {
        axios.delete(`/Instituicao/${instituicaoId}`
        ).then( response => 
            {
               
                this.find();
            }
        ).catch( error => 
            {
                console.log(error.response);
            }
        );
    }

    edit = (instituicaoId) => {
        this.props.history.push(`/updateInstituicao/${instituicaoId}`);
    }


    render() {
        return (
            <div>
                
                
                <Card title="Consulta Instituições">
                    <hr />
                    <FormGroup label="Nome" htmlFor="inputNome">
                        <input type="text" className="form-control" 
                            placeholder="Digite o nome" id="inputNome"
                            value={this.state.nome} 
                            onChange={(e) => this.setState({ nome: e.target.value })} />

                    </FormGroup>

                    <FormGroup label="Email" htmlFor="inputEmail">
                         <input type="email" className="form-control" 
                         placeholder="Digite um email" 
                         id="inputEmail"
                         value={this.state.email} 
                         onChange={(e) => this.setState({ email: e.target.value })} />

                    </FormGroup>
                    <FormGroup label="Telefone" htmlFor="inputTelefone">
                        <input type="tel" 
                            className="form-control" 
                            placeholder="Digite um telefone" 
                            id="inputTelefone"
                            value={this.state.telefone} 
                            onChange={(e) => this.setState({ telefone: e.target.value })} />

                    </FormGroup>

                    <br />
                    
                    <button onClick={this.find} type="button" className="btn btn-success">Buscar
                    
                        <i className="pi pi-search"></i>
                   </button>
                    <br />
                    <div className="row" >
                        <div className="col-md-12">
                            <div className="bs-component" >
                                <br />
                                <InstituicaoTables instituicoes = {this.state.instituicoes} 
                                delete ={this.delete}
                                edit= {this.edit} />
                            </div>
                        </div>  
                    </div>          
                    
               </Card>
            </div>


        )
    }

}
export default withRouter(ViewInstituicao);